Xét thuật toán sắp xếp sau:
public static void mysterySort(Comparable[] a) {
int n = a.length;
for (int i = 0; i < n; i++) { boolean exchanged = false;
for (int j = 0; j < n - i - 1; j++) { if (less(a[j+1], a[j])) {
exch(a, j+1, j); exchanged = true;
}
}
if (!exchanged) break;  	// no exchanges, already sorted
}
}

a. Bất biến đúng tại điểm bắt đầu của mỗi lần lặp:

i phần tử đầu tiên trong mảng đã được sắp xếp đúng thứ tự  (X) 
i phần tử cuối cùng trong mảng đã được sắp xếp đúng thứ tự (V)
i phần tử đầu tiên trong mảng là i phần tử nhỏ nhất của mảng (X)
i phần tử cuối cùng trong mảng là i phần tử lớn nhất của mảng (V)


b. Thuật toán trên là thuật toán sắp xếp tại chỗ, đổi chỗ bé hơn và lớn hơn

c. Thuật toán có stable, chỉ swap khi less(a[j+1] , a[j]), chỉ đổi chỗ khi phần tử bên phải nhỏ hơn nghiệm ngặt phàn từ bên trái -> stable

d.  Số lần gọi hàm exch() để sắp xếp một mảng số nguyên có dạng [2,3,4,..n-1, n] - A.0 -> k phải exch do less

Số lần gọi less() trong trường hợp tốt nhất (best case) - C.n

Số lần gọi less() trong trường hợp tồi nhất (worst case) - H.1/2n^2

