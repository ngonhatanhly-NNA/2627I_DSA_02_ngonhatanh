import java.util.Scanner;

public class Solution {
    static class Node {
        int val;
        Node left;
        Node right;
        int ht;
    }

    static int getHeight(Node n) {
        if (n == null) return -1;
        return n.ht;
    }

    static int getBalance(Node n) {
        if (n == null) return 0;
        return getHeight(n.left) - getHeight(n.right);
    }

    static void updateHeight(Node n) {
        n.ht = Math.max(getHeight(n.left), getHeight(n.right)) + 1;
    }

    static Node rotateRight(Node y) {
        Node x = y.left;
        Node T2 = x.right;
        x.right = y;
        y.left = T2;
        updateHeight(y);
        updateHeight(x);
        return x;
    }

    static Node rotateLeft(Node x) {
        Node y = x.right;
        Node T2 = y.left;
        y.left = x;
        x.right = T2;
        updateHeight(x);
        updateHeight(y);
        return y;
    }

    static Node insert(Node root, int val) {
        if (root == null) {
            Node newNode = new Node();
            newNode.val = val;
            newNode.left = null;
            newNode.right = null;
            newNode.ht = 0;
            return newNode;
        }

        if (val < root.val) {
            root.left = insert(root.left, val);
        } else if (val > root.val) {
            root.right = insert(root.right, val);
        } else {
            return root;
        }

        updateHeight(root);
        int balance = getBalance(root);

        if (balance > 1 && val < root.left.val) return rotateRight(root);
        if (balance < -1 && val > root.right.val) return rotateLeft(root);
        if (balance > 1 && val > root.left.val) {
            root.left = rotateLeft(root.left);
            return rotateRight(root);
        }
        if (balance < -1 && val < root.right.val) {
            root.right = rotateRight(root.right);
            return rotateLeft(root);
        }

        return root;
    }

    static void inOrder(Node root) {
        if (root == null) return;
        inOrder(root.left);
        System.out.print(root.val + "(BF=" + getBalance(root) + ") ");
        inOrder(root.right);
    }

    static void preOrder(Node root) {
        if (root == null) return;
        System.out.print(root.val + "(BF=" + getBalance(root) + ") ");
        preOrder(root.left);
        preOrder(root.right);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        if (!sc.hasNextInt()) return;

        int n = sc.nextInt();
        Node root = null;

        for (int i = 0; i < n; i++) {
            int val = sc.nextInt();
            root = insert(root, val);
        }

        if (sc.hasNextInt()) {
            int valToInsert = sc.nextInt();
            root = insert(root, valToInsert);
        }

        inOrder(root);
        System.out.println();
        preOrder(root);
        System.out.println();

        sc.close();
    }
}