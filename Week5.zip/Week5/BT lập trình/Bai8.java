class PriorityQueue{
	
	private int[] arr;
	private int size;
	
	public PriorityQueue(int capacity){
			arr = new int[capacity];
			size = 0;
	}
	public void insert(int val){
		arr[size] = val;
		size++;
	}
	
	public int deleteMin(int val){
		int currMin = Integer.MAX_VALUE;
        int minIndex = 0;

        for (int i = 0; i < size; i++) {
            if (arr[i] < currMin) {
                currMin = arr[i];
                minIndex = i;
            }
        }
		
		for (int i = minIndex; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }

        size--;
		return currMin;
	}
}