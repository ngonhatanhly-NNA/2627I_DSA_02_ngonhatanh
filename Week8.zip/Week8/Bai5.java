import java.util.*;

class Solution {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        if (!scanner.hasNextInt()) return;
        
        int height = scanner.nextInt();
        Tree tree = new Tree();

        while (scanner.hasNextInt()) {
            tree.values.add(scanner.nextInt());
        }
        scanner.close();

        tree = tree.getNodeInserted(tree, height);
    }
}

class Tree {
    Vector<Integer> values;
    private int count;

    Tree() {
        this.values = new Vector<Integer>();
        this.count = 0;
    }

    class Node {
        int data;
        Node left;
        Node right;

        Node() {
            this.data = -1;
            this.left = null;
            this.right = null;
        }
    }

    boolean checkBST(Node root) {
        return checkBST(root, Long.MIN_VALUE, Long.MAX_VALUE);
    }

    boolean checkBST(Node root, long min, long max) {
        if (root == null) {
            return true;
        }
        if (root.data <= min || root.data >= max) {
            return false;
        }
        return checkBST(root.left, min, root.data)
                && checkBST(root.right, root.data, max);
    }

    void inOrder(Node root, int levels) {
        if (root != null) {
            if (levels > 0) {
                root.left = new Node();
                inOrder(root.left, levels - 1);
            }
            
            if (count < values.size()) {
                root.data = values.elementAt(count);
                count++;
            }

            if (levels > 0) {
                root.right = new Node();
                inOrder(root.right, levels - 1);
            }
        }
    }

    Tree getNodeInserted(Tree tree, int height) {
        Node root = new Node();
        tree.inOrder(root, height);
        System.out.println(tree.checkBST(root) ? "Yes" : "No");
        return tree;
    }
}