import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

class Result {

    /*
     * Complete the 'missingNumbers' function below.
     *
     * The function is expected to return an INTEGER_ARRAY.
     * The function accepts following parameters:
     *  1. INTEGER_ARRAY arr
     *  2. INTEGER_ARRAY brr
     */

    public static List<Integer> missingNumbers(List<Integer> arr, List<Integer> brr) {
    // Write your code here
        Map<Integer, Integer> freqMap = new HashMap<>();
        
        for(int num : brr){
            freqMap.put(num, freqMap.getOrDefault(num, 0) + 1); 
        }
        
        for (int num : arr){
            freqMap.put(num,freqMap.get(num) - 1);
        }
        
        List<Integer> missing = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : freqMap.entrySet()){
            if (entry.getValue() > 0){
                missing.add(entry.getKey());
            }
        }
        Collections.sort(missing);
        return missing;

    }
    
    public static List<Integer> missingNumbers2(List<Integer> arr, List<Integer> brr){
        Collections.sort(arr);
        Collections.sort(brr);
        
        List<Integer> missing = new ArrayList<>();
        int i = 0;
        int j = 0;
        
        while (j < brr.size()){
            if (i >= arr.size() || !arr.get(i).equals(brr.get(j))){
                int val = brr.get(j);
                
                if (missing.isEmpty() || missing.get(missing.size() - 1) != val){
                    missing.add(val);
                }
                j++;
            } else {
                i++;
                j++;
            }
        }  
        return missing;
    }
     public static List<Integer> missingNumbers3(List<Integer> arr, List<Integer> brr) {
    // Write your code here
        int minVal = Collections.min(brr);
        int[] count = new int[101];
        
        for (int num : brr){
            count[num - minVal]++;
        }
        
        for (int num : arr){
            count[num - minVal]--;
        }
        
        List<Integer> missing = new ArrayList<>();
        for (int i = 0; i < 101; i++) {
            if (count[i] > 0) {
                missing.add(i + minVal);
            }
        }
        
        return missing;
    }

}

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int n = Integer.parseInt(bufferedReader.readLine().trim());

        List<Integer> arr = Stream.of(bufferedReader.readLine().replaceAll("\\s+$", "").split(" "))
            .map(Integer::parseInt)
            .collect(toList());

        int m = Integer.parseInt(bufferedReader.readLine().trim());

        List<Integer> brr = Stream.of(bufferedReader.readLine().replaceAll("\\s+$", "").split(" "))
            .map(Integer::parseInt)
            .collect(toList());

        List<Integer> result = Result.missingNumbers(arr, brr);

        bufferedWriter.write(
            result.stream()
                .map(Object::toString)
                .collect(joining(" "))
            + "\n"
        );

        bufferedReader.close();
        bufferedWriter.close();
    }
}
