Xét một mảng 2n phần tử ở dạng 1, n+1, 2, n+2, 3, n+3, …, n, 2n
Ví dụ với n=8 mảng có nội dung như sau:  1  9  2  10  3  11  4  12  5  13  6  14  7  15  8  16
Hỏi mỗi thuật toán sắp xếp dưới đây dùng đến bao nhiêu phép so sánh, tính theo n? Chú ý rằng mảng có độ dài 2n, không phải n.

Selection sort:      ~ ¼ n2	~ ½ n2	~ n2	~¼ n2	~ 3/2 n2	~ 2 n2	
Insertion sort:      ~ ¼ n2	~ ½ n2	~ n2	~¼ n2	~ 3/2 n2	~ 2 n2	
Mergesort:      ~ ¼ n log n	~ ½ log n	~ n log n	~ 3/2 n log n	~ 2 n log n	


- Selection sort: chạy vòng lặp (2n - 1) đầu và ở mỗi phần sau, chạy lần luợt là 2n - 1, 2n - 2, .... -> 2n(2n - 1)/ 2 -> 2n^2 
- Insertion sort: số làn phải dịch chuyển trong số từ 1 - > 2n 
	1 + 2 + 3 + ... + (n - 1) = n(n - 1) / 2 -> khoảng 1/2*n^2 

- Merge sort:3/2 * nlogn
Trên mảng 1 -> 2n; chia nhỏ dần , mỗi lần chia nhỏ 2n -> n -> n / 2
có 3 comparision ở tầng 2 - 2 -> 3 * n / 2 và bước chia 2n là logn

-> 3/2nlogns