1. COS226, Midterm f25, 2b
- Các cặp key được gọi để so sánh trong quá trình chạy hàm swim  là: 
+ So sánh nút mới (giá trị 77) với nút cha trực tiếp là 10. Do $77 > 10$, thực hiện đổi chỗ. Cặp key so sánh là (77, 10).   

+ Nút 77 lúc này tiếp tục được so sánh với nút cha tiếp theo là 75. Do $77 > 75$, thực hiện đổi chỗ tiếp để đưa 77 lên làm gốc. Cặp key so sánh là (77, 75). 

+ Nút 77 tiếp tục so sánh với nút cha gốc là 80. Vì $77 < 80$, điều kiện swim() dừng lại, không đổi chỗ thêm.

2. COS226, Midterm s25, 2b

- Delete max xóa phần từ lớn nhất, và cho phần tử cuối lên đầu  -> So sánh 50 với 75 -> 50 - 66 -> 50 - 30, đã về đúng -> dừng

3. COS226, Midterm f24, 4b

- Không thể là cây nhị phân max heap, vì ở nút 65 không có con mà nút 35 lại có 2 con dù vị trí ở sau -> max_heap k thể bị trống lủng ở giữa -> k phải max_heap

4. COS226, Midterm f25, 1b

Vòng lặp insert (chèn $n$ phần tử):Vòng lặp for thực hiện $n$ lần phép pq.insert().   
Mỗi thao tác insert vào binary heap tốn thời gian $O(\log n)$ trong trường hợp tồi nhất.   Tổng thời gian cho vòng lặp 1 là: $n \times O(\log n) = O(n \log n)$.   

Vòng lặp delMin (xóa $n$ phần tử min):Vòng lặp for thực hiện $n$ lần phép pq.delMin().   Mỗi thao tác delMin trên binary heap (sau khi lấy min ở gốc $O(1)$ thì phải chạy sink để khôi phục heap) tốn thời gian $O(\log n)$ trong trường hợp tồi nhất.   Tổng thời gian cho vòng lặp 2 là: $n \times O(\log n) = O(n \log n)$.   

Tổng thời gian tồi nhất:$$O(n \log n) + O(n \log n) = \Theta(n \log n)$$