package Week4.Lecture;

import edu.princeton.cs.algs4.In;

public class Selection {

    public static void sort(int[] a) {
        int n = a.length;
        for (int i = 0; i < n; i++) {
            int min = i;
            for (int j = i + 1; j < n; j++) {
                if (a[j] < a[min]) {
                    min = j;
                }
            }
            int swap = a[i];
            a[i] = a[min];
            a[min] = swap;
        }
    }

    public static void main(String[] args) {
        // Đảm bảo file dữ liệu (ví dụ 4Kints.txt) nằm đúng đường dẫn mà Java có thể đọc được
        In in = new In("Week4/Lecture/4Kints.txt"); 
        int[] a = in.readAllInts();

        long start = System.currentTimeMillis();
        sort(a);
        long end = System.currentTimeMillis();

        System.out.println("Selection Sort - Thoi gian chay: " + (end - start) + " ms");
    }
}