
```markdown
# Giải Bài Tập Cấu Trúc Dữ Liệu Cây

**Dãy dữ liệu đầu vào:** `1, 3, 10, 9, 6, 7, 4, 5, 2, 8`

---

## Câu a: Cây thứ tự bộ phận (Max-Heap)

### 1. Quá trình thêm lần lượt các phần tử (Insert & Swim/Heapify-Up)
*Quy tắc: Chèn vào vị trí trống tiếp theo (từ trái sang phải theo từng mức), sau đó đổi chỗ với nút cha nếu nút con lớn hơn nút cha.*

* **Thêm 1:** `[1]`
* **Thêm 3:** `[1, 3]` $\rightarrow$ Đổi chỗ `3` và `1` $\rightarrow$ `[3, 1]`
* **Thêm 10:** `[3, 1, 10]` $\rightarrow$ Đổi chỗ `10` và `3` $\rightarrow$ `[10, 1, 3]`
* **Thêm 9:** `[10, 1, 3, 9]` $\rightarrow$ Đổi chỗ `9` và `1` $\rightarrow$ `[10, 9, 3, 1]`
* **Thêm 6:** `[10, 9, 3, 1, 6]` (Giữ nguyên vì $6 < 9$)
* **Thêm 7:** `[10, 9, 3, 1, 6, 7]` $\rightarrow$ Đổi chỗ `7` và `3` $\rightarrow$ `[10, 9, 7, 1, 6, 3]`
* **Thêm 4:** `[10, 9, 7, 1, 6, 3, 4]` (Giữ nguyên vì $4 < 7$)
* **Thêm 5:** `[10, 9, 7, 1, 6, 3, 4, 5]` $\rightarrow$ Đổi chỗ `5` và `1` $\rightarrow$ `[10, 9, 7, 5, 6, 3, 4, 1]`
* **Thêm 2:** `[10, 9, 7, 5, 6, 3, 4, 1, 2]` (Giữ nguyên vì $2 < 5$)
* **Thêm 8:** `[10, 9, 7, 5, 6, 3, 4, 1, 2, 8]` $\rightarrow$ Đổi chỗ `8` và `6` $\rightarrow$ `[10, 9, 7, 5, 8, 3, 4, 1, 2, 6]`

**Cây Max-Heap hoàn chỉnh sau khi thêm:**
```text
          10
        /    \
       9      7
      / \    / \
     5   8  3   4
    / \ /
   1  2 6

```

*Biểu diễn mảng:* `[10, 9, 7, 5, 8, 3, 4, 1, 2, 6]`

---

### 2. Quá trình lấy và xoá phần tử lớn nhất 4 lần liên tiếp (Extract-Max & Sink/Heapify-Down)

*Quy tắc: Lấy nút gốc, đưa phần tử cuối cùng lên làm gốc, sau đó đổi chỗ xuống dưới với nút con lớn hơn cho đến khi thỏa mãn tính chất Max-Heap.*

* **Lần 1: Lấy `10**`
* Đưa `6` lên gốc: `[6, 9, 7, 5, 8, 3, 4, 1, 2]`
* Sink `6`: Đổi chỗ `6` với `9` $\rightarrow$ Đổi chỗ `6` với `8`
* **Mảng sau lần 1:** `[9, 8, 7, 5, 6, 3, 4, 1, 2]`


* **Lần 2: Lấy `9**`
* Đưa `2` lên gốc: `[2, 8, 7, 5, 6, 3, 4, 1]`
* Sink `2`: Đổi chỗ `2` với `8` $\rightarrow$ Đổi chỗ `2` với `6`
* **Mảng sau lần 2:** `[8, 6, 7, 5, 2, 3, 4, 1]`


* **Lần 3: Lấy `8**`
* Đưa `1` lên gốc: `[1, 6, 7, 5, 2, 3, 4]`
* Sink `1`: Đổi chỗ `1` với `7` $\rightarrow$ Đổi chỗ `1` với `4`
* **Mảng sau lần 3:** `[7, 6, 4, 5, 2, 3, 1]`


* **Lần 4: Lấy `7**`
* Đưa `1` lên gốc: `[1, 6, 4, 5, 2, 3]`
* Sink `1`: Đổi chỗ `1` với `6` $\rightarrow$ Đổi chỗ `1` với `5`
* **Mảng sau lần 4:** `[6, 5, 4, 1, 2, 3]`



**Cây Max-Heap sau 4 lần xoá:**

```text
        6
      /   \
     5     4
    / \   /
   1   2 3

```

---

## Câu b: Cây tìm kiếm nhị phân (BST)

### 1. Cây BST sau khi thêm lần lượt `1, 3, 10, 9, 6, 7, 4, 5, 2, 8`

*Quy tắc: Nhỏ hơn đi sang trái, lớn hơn đi sang phải.*

```text
    1
     \
      3
     / \
    2   10
       /
      9
     /
    6
   / \
  4   7
   \   \
    5   8

```

### 2. Quá trình xoá lần lượt `3, 5, 7, 9`

*(Sử dụng quy tắc Hibbard Deletion: thay bằng phần tử nhỏ nhất của cây con bên phải - Inorder Successor nếu nút có 2 con)*

* **Xoá `3`:** Nút `3` có 2 con (`2` và `10`). Phần tử nhỏ nhất bên phải của `3` là `4`. Thay `3` bằng `4`, đồng thời nối con phải của `4` (là `5`) lên vị trí cũ của `4`.

```text
    1
     \
      4
     / \
    2   10
       /
      9
     /
    6
   / \
  5   7
       \
        8

```

* **Xoá `5`:** Nút `5` là nút lá $\rightarrow$ Xoá trực tiếp.

```text
    1
     \
      4
     / \
    2   10
       /
      9
     /
    6
     \
      7
       \
        8

```

* **Xoá `7`:** Nút `7` chỉ có 1 con phải là `8` $\rightarrow$ Nối thẳng `6` với `8`.

```text
    1
     \
      4
     / \
    2   10
       /
      9
     /
    6
     \
      8

```

* **Xoá `9`:** Nút `9` chỉ có 1 con trái là `6` $\rightarrow$ Nối thẳng `10` với `6`.

```text
    1
     \
      4
     / \
    2   10
       /
      6
       \
        8

```

---

## Câu c: Cây tìm kiếm cân bằng (Cây AVL)

### 1. Quá trình thêm lần lượt `1, 3, 10, 9, 6, 7, 4, 5, 2, 8`

* **Thêm `1, 3, 10`:** Mất cân bằng tại `1` (lệch phải-phải / RR) $\rightarrow$ **Xoay trái tại `1**`. Gốc mới là `3`.
* **Thêm `9, 6`:** Mất cân bằng tại `10` (lệch trái-trái / LL) $\rightarrow$ **Xoay phải tại `10**`. Cụm bên phải thành `9` (con trái `6`, con phải `10`).
* **Thêm `7`:** Mất cân bằng tại `3` (lệch phải-trái / RL). Xoay phải tại `9`, sau đó **xoay trái tại `3**`. Gốc mới là `6`.
* *Cây lúc này:* Gốc `6`; trái là `3` (con `1`); phải là `9` (con trái `7`, con phải `10`).


* **Thêm `4`:** Chèn vào con phải của `3` (cây vẫn cân bằng).
* **Thêm `5`:** Mất cân bằng tại `3` (lệch phải-phải / RR tại nhánh `3-4-5`) $\rightarrow$ **Xoay trái tại `3**`. Nhánh trái của `6` thành `4` (con trái `3`, con phải `5`).
* **Thêm `2`:** Chèn vào con phải của `1` (cây vẫn cân bằng).
* **Thêm `8`:** Chèn vào con phải của `7` (cây vẫn cân bằng).

**Cây AVL hoàn chỉnh sau khi thêm:**

```text
          6
        /   \
       4     9
      / \   / \
     3   5 7   10
    /       \
   1         8
    \
     2

```

---

### 2. Quá trình xoá lần lượt `3, 5, 7, 9`

* **Xoá `3`:**
* Nút `3` có 1 con trái là `1` (kèm con phải `2`). Thay `3` bằng `1`.
* Kiểm tra cân bằng tại `1`: lệch phải-phải (`1` có con phải `2`, chiều cao lệch 2? Không, nút `1` chỉ có 1 con phải là `2` nên cân bằng; nhưng tại nút `4`, chiều cao nhánh trái là 2, nhánh phải là 1 $\rightarrow$ vẫn cân bằng).


```text
        6
      /   \
     4     9
    / \   / \
   1   5 7   10
    \     \
     2     8

```


* **Xoá `5`:**
* Xoá nút lá `5`.
* Tại nút `4`: nhánh trái cao 2 (`1-2`), nhánh phải cao 0 $\rightarrow$ Mất cân bằng **Trái-Phải (LR)** tại `4`.
* **Xử lý:** Xoay trái tại `1` (đưa `2` lên), sau đó **xoay phải tại `4**`. Nhánh trái của `6` trở thành `2` (con trái `1`, con phải `4`).


```text
        6
      /   \
     2     9
    / \   / \
   1   4 7   10
          \
           8

```


* **Xoá `7`:**
* Nút `7` chỉ có 1 con phải là `8` $\rightarrow$ Thay `7` bằng `8`. Cây vẫn cân bằng.


```text
        6
      /   \
     2     9
    / \   / \
   1   4 8   10

```


* **Xoá `9`:**
* Nút `9` có 2 con (`8` và `10`). Thay bằng phần tử nhỏ nhất bên phải là `10`.
* Cây hoàn toàn cân bằng.



**Cây AVL cuối cùng:**

```text
          6
        /   \
       2     10
      / \   /
     1   4 8

```

```

```