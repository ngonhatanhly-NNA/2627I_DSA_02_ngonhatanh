
import java.util.Scanner;

class Node {
    String label;
    int id;
    int firstChild;
    int nextSibling;

    public Node(String label, int id, int firstChild, int nextSibling) {
        this.label = label;
        this.id = id;
        this.firstChild = firstChild;
        this.nextSibling = nextSibling;
    }
}

public class GeneralTree {
    static Node[] tree;
    static int n;

    public static int findParent(int x) {
        for (int i = 0; i < n; i++) {
            int child = tree[i].firstChild;

            while (child != -1) {
                if (tree[child].id == x)
                    return tree[i].id;

                child = tree[child].nextSibling;
            }
        }
        return -1;
    }

    public static int findFirstChild(int x) {
        for (int i = 0; i < n; i++) {
            if (tree[i].id == x) {
                return tree[i].firstChild;
            }
        }
        return -1;
    }

    public static int findNextSibling(int x) {
        for (int i = 0; i < n; i++) {
            if (tree[i].id == x) {
                return tree[i].nextSibling;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        n = sc.nextInt();
        tree = new Node[n];

        for (int i = 0; i < n; i++) {
            String label = sc.next();
            int id = sc.nextInt();
            int firstChild = sc.nextInt();
            int nextSibling = sc.nextInt();

            tree[i] = new Node(label, id, firstChild, nextSibling);
        }

        int x = sc.nextInt();

        System.out.println("Parent: " + findParent(x));
        System.out.println("FirstChild: " + findFirstChild(x));
        System.out.println("NextSibling: " + findNextSibling(x));

        sc.close();
    }
}
