import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

class Result {
    static class Node implements Comparable<Node>{
        int val;
        int idx;
        
        Node(int val, int idx){
            this.val = val;
            this.idx = idx;
        }
        @Override
        public int compareTo(Node other){
            if (this.val != other.val){
                return Integer.compare(this.val, other.val);
            }
            
            return Integer.compare(this.idx, other.idx);
        }
    /*
     * Complete the 'runningMedian' function below.
     *
     * The function is expected to return a DOUBLE_ARRAY.
     * The function accepts INTEGER_ARRAY a as parameter.
     */

    public static List<Double> runningMedian(List<Integer> a) {
    // Write your code here
        List<Double> res = new ArrayList<>();
        TreeSet<Node> set = new TreeSet<>();
        Node mid = null;
        
        for (int i = 0; i < a.size(); i++){
            Node curr = new Node(a.get(i), i);
            set.add(curr);
            
            if (i == 0) {
                mid = curr;
            } else if (set.size() % 2 == 0) {
                if (curr.compareTo(mid) < 0) {
                    mid = set.lower(mid);
                }
            } else {
                if (curr.compareTo(mid) > 0) {
                    mid = set.higher(mid);
                }
            }
            
            if (set.size() % 2 == 1){
                res.add((double) mid.val);
            } else {
                res.add(((mid.val + set.higher(mid).val) / 2.0));
            }
        }
        return res;  
    }
    }}

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int aCount = Integer.parseInt(bufferedReader.readLine().trim());

        List<Integer> a = IntStream.range(0, aCount).mapToObj(i -> {
            try {
                return bufferedReader.readLine().replaceAll("\\s+$", "");
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        })
            .map(String::trim)
            .map(Integer::parseInt)
            .collect(toList());

        List<Double> result = Result.runningMedian(a);

        bufferedWriter.write(
            result.stream()
                .map(Object::toString)
                .collect(joining("\n"))
            + "\n"
        );

        bufferedReader.close();
        bufferedWriter.close();
    }
}
