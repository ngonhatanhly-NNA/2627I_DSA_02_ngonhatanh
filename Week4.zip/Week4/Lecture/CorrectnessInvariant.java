import java.io.*;
import java.util.*;

public class CorrectnessInvariant {

    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner sc = new Scanner(System.in);
        
        int n = sc.nextInt();
        int[] ar = new int[n];
        
        for (int i = 0; i < n; i++){
            ar[i] = sc.nextInt();
        }
        
        insertIntoSorted(ar);
        sc.close();
    }
    
    public static void insertIntoSorted(int[] ar){
        for (int i = 1; i < ar.length; i++) {
            int key = ar[i];
            int j = i - 1;

            while (j >= 0 && ar[j] > key) {
                ar[j + 1] = ar[j];
                j--;
            }
            ar[j + 1] = key;
        }
        for (int i = 0; i < ar.length; i++) {
            System.out.print(ar[i] + (i == ar.length - 1 ? "" : " "));
        }
        System.out.println();
    }
}