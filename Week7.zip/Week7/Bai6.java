import java.util.*;

public class MainTreeMap {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, Integer> wordMap = new TreeMap<>();

        while (scanner.hasNext()) {
            // Loại bỏ dấu câu và chuyển về chữ thường
            String word = scanner.next().replaceAll("[^a-zA-Z0-9àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđĐ]", "").toLowerCase();
            
            if (!word.isEmpty()) {
                wordMap.put(word, wordMap.getOrDefault(word, 0) + 1);
            }
        }

        // TreeMap tự động sắp xếp key theo thứ tự từ điển A-Z
        for (Map.Entry<String, Integer> entry : wordMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}