```java
import java.util.Arrays;
import java.util.Random;

public class QuickSortComparison {

    // ==================================================
    // INSERTION SORT
    // ==================================================
    public static void insertionSort(int[] a) {

        for (int i = 1; i < a.length; i++) {

            int key = a[i];
            int j = i - 1;

            while (j >= 0 && a[j] > key) {
                a[j + 1] = a[j];
                j--;
            }

            a[j + 1] = key;
        }
    }


    // ==================================================
    // MERGE SORT
    // ==================================================
    public static void mergeSort(int[] a) {

        int[] aux = new int[a.length];

        mergeSort(a, aux, 0, a.length - 1);
    }

    private static void mergeSort(
            int[] a,
            int[] aux,
            int lo,
            int hi) {

        if (hi <= lo) {
            return;
        }

        int mid = lo + (hi - lo) / 2;

        mergeSort(a, aux, lo, mid);
        mergeSort(a, aux, mid + 1, hi);

        merge(a, aux, lo, mid, hi);
    }

    private static void merge(
            int[] a,
            int[] aux,
            int lo,
            int mid,
            int hi) {

        for (int k = lo; k <= hi; k++) {
            aux[k] = a[k];
        }

        int i = lo;
        int j = mid + 1;

        for (int k = lo; k <= hi; k++) {

            if (i > mid) {
                a[k] = aux[j++];
            }
            else if (j > hi) {
                a[k] = aux[i++];
            }
            else if (aux[j] < aux[i]) {
                a[k] = aux[j++];
            }
            else {
                a[k] = aux[i++];
            }
        }
    }


    // ==================================================
    // QUICKSORT - NO SHUFFLE
    // ==================================================
    public static void quickSortNoShuffle(int[] a) {

        quickSortNoShuffle(a, 0, a.length - 1);
    }

    private static void quickSortNoShuffle(
            int[] a,
            int lo,
            int hi) {

        if (hi <= lo) {
            return;
        }

        int j = partition(a, lo, hi);

        quickSortNoShuffle(a, lo, j - 1);
        quickSortNoShuffle(a, j + 1, hi);
    }


    // ==================================================
    // QUICKSORT - WITH SHUFFLE
    // ==================================================
    public static void quickSortShuffle(int[] a) {

        shuffle(a);

        quickSortNoShuffle(a, 0, a.length - 1);
    }


    // ==================================================
    // PARTITION
    // ==================================================
    private static int partition(
            int[] a,
            int lo,
            int hi) {

        int pivot = a[lo];

        int i = lo;
        int j = hi + 1;

        while (true) {

            // Scan from left
            while (a[++i] < pivot) {

                if (i == hi) {
                    break;
                }
            }

            // Scan from right
            while (pivot < a[--j]) {

                if (j == lo) {
                    break;
                }
            }

            if (i >= j) {
                break;
            }

            swap(a, i, j);
        }

        swap(a, lo, j);

        return j;
    }


    // ==================================================
    // SHUFFLE
    // ==================================================
    private static void shuffle(int[] a) {

        Random random = new Random();

        for (int i = a.length - 1; i > 0; i--) {

            int j = random.nextInt(i + 1);

            swap(a, i, j);
        }
    }


    // ==================================================
    // SWAP
    // ==================================================
    private static void swap(
            int[] a,
            int i,
            int j) {

        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }


    // ==================================================
    // RANDOM DATA
    // ==================================================
    public static int[] randomArray(int n) {

        Random random = new Random();

        int[] a = new int[n];

        for (int i = 0; i < n; i++) {
            a[i] = random.nextInt(n);
        }

        return a;
    }


    // ==================================================
    // SORT TYPE
    // ==================================================
    public static double measure(
            int[] original,
            int algorithm) {

        int[] a = Arrays.copyOf(
                original,
                original.length
        );

        long start = System.nanoTime();

        switch (algorithm) {

            case 1:
                insertionSort(a);
                break;

            case 2:
                mergeSort(a);
                break;

            case 3:
                quickSortShuffle(a);
                break;

            case 4:
                quickSortNoShuffle(a);
                break;
        }

        long end = System.nanoTime();

        return (end - start) / 1_000_000.0;
    }


    // ==================================================
    // MAIN
    // ==================================================
    public static void main(String[] args) {

        int[] sizes = {
            1000,
            5000,
            10000,
            50000,
            100000
        };

        System.out.printf(
                "%-10s %-15s %-15s %-20s %-20s%n",
                "N",
                "Insertion",
                "Merge",
                "Quick+Shuffle",
                "Quick"
        );

        System.out.println(
                "-------------------------------------------------------------------------------"
        );

        for (int n : sizes) {

            int[] data = randomArray(n);

            double insertion =
                    measure(data, 1);

            double merge =
                    measure(data, 2);

            double quickShuffle =
                    measure(data, 3);

            double quickNoShuffle =
                    measure(data, 4);

            System.out.printf(
                    "%-10d %-15.3f %-15.3f %-20.3f %-20.3f%n",
                    n,
                    insertion,
                    merge,
                    quickShuffle,
                    quickNoShuffle
            );
        }
    }
}
```