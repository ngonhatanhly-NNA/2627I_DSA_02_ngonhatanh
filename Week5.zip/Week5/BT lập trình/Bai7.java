import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

class Result {

    /*
     * Complete the 'findMedian' function below.
     *
     * The function is expected to return an INTEGER.
     * The function accepts INTEGER_ARRAY arr as parameter.
     */

    public static int findMedian(List<Integer> arr) {
    // Write your code here
        int target = arr.size() / 2;
        return quickSelect(arr, 0, arr.size() - 1, target);
    }        
    
    public static int quickSelect(List<Integer> arr, int low, int high, int target){
        if (low <= high){
            int p = partition(arr, low, high);
            
            if (p == target){
                return arr.get(p);
            } else if (p > target){
                return quickSelect(arr, low, p - 1, target);
            } else {
                return quickSelect(arr, p + 1, high, target);
            }
        }
        
        return -1;
    }
    
    public static int partition(List<Integer> arr, int low, int high){
        int pivot = arr.get(high);
        
        int i = low - 1;
        
        for (int j = low; j < high; j++){
            if (arr.get(j) < pivot){
                i++;
                int temp = arr.get(i);
                arr.set(i, arr.get(j));
                arr.set(j, temp);
            }
        }
        
        int temp = arr.get(i + 1);
        arr.set(i + 1, arr.get(high));
        arr.set(high, temp);
        
        return i + 1;
    }


}

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int n = Integer.parseInt(bufferedReader.readLine().trim());

        List<Integer> arr = Stream.of(bufferedReader.readLine().replaceAll("\\s+$", "").split(" "))
            .map(Integer::parseInt)
            .collect(toList());

        int result = Result.findMedian(arr);

        bufferedWriter.write(String.valueOf(result));
        bufferedWriter.newLine();

        bufferedReader.close();
        bufferedWriter.close();
    }
}
