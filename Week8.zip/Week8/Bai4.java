import java.io.*;
import java.util.*;

public class Solution {

    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        Node root = null;
        for (int i = 0; i < n; i++) {
            int data = sc.nextInt();
            root = insert(root, data);
        }
        
        int v1 = sc.nextInt();
        int v2 = sc.nextInt();
        sc.close();
        
        Node ans = lca(root, v1, v2);
        if (ans != null) {
            System.out.println(ans.data);
        }
    }
    
    public static Node insert(Node root, int data){
        if (root == null) {
            return new Node(data);
        }
        
        if (data < root.data) {
            root.left = insert(root.left, data);
        } else if (data > root.data) {
            root.right = insert(root.right, data);
        }
        
        return root;
    }
    
    public static Node lca(Node root, int v1, int v2){
        while (root != null){
            if (root.data > v1 && root.data > v2){
                root = root.left;
            } else if (root.data < v1 && root.data < v2){
                root = root.right;
            } else {
                return root;
            }
        }
        
        return null;
    }
}

class Node{
    int data;
    Node left;
    Node right;
    
    Node(int data){
        this.data = data;
        left = null;
        right = null;
    }
}