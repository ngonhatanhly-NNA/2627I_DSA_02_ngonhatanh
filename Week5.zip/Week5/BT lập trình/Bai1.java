```java
public class BinarySearch {

    public static int binarySearch(int[] a, int key) {
        int lo = 0;
        int hi = a.length - 1;

        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2;

            if (a[mid] == key) {
                return mid;
            } else if (a[mid] < key) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }

        return -1;
    }

    public static void main(String[] args) {

        int[] a = {1, 3, 5, 7, 9, 11, 13, 15, 17};

        int key = 13;

        int index = binarySearch(a, key);

        System.out.println("Array:");
        for (int x : a) {
            System.out.print(x + " ");
        }

        System.out.println();

        if (index != -1) {
            System.out.println("Found " + key + " at index " + index);
        } else {
            System.out.println(key + " not found");
        }
    }
}
```