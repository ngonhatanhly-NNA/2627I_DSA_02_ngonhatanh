import java.util.Scanner;

public class HIndex {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int n = scanner.nextInt();
        int[] citations = new int[n];
        for (int i = 0; i < n; i++) {
            citations[i] = scanner.nextInt();
        }
        
        int left = 0, right = n;
        int hIndex = 0;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (isValid(citations, mid)) {
                hIndex = mid;      
                left = mid + 1;    /
            } else {
                right = mid - 1;  
            }
        }
        
        System.out.println(hIndex);
        scanner.close();
    }
    
    public static boolean isValid(int[] citations, int h) {
        int count = 0;
        for (int c : citations) {
            if (c >= h) {
                count++;
            }
        }
        return count >= h;
    }
}