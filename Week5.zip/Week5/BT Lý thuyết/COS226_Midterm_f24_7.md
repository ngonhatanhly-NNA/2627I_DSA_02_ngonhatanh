
Giả sử n là một lũy thừa của 2. Xét một mảng có cấu trúc như sau
2n 2n … 2n 0 1 2 2 4 4 4 4 8 8 8 8 8 8 8 8 … n n … n
Nửa đầu của mảng chứa 2n lần lặp lại của giá trị 2n. Nửa sau chứa 2n số: một số 0, một số 1, hai lần lặp lại của số 2, bốn lần lặp lại của số 4, tám lần lặp lại của số 8, mười sáu lần lặp lại của số 16, và cứ tiếp tục như vậy cho đến khi số n xuất hiện n lần.
Ví dụ, với n = 4 mảng có nội dung sau
8 8 8 8	8 8 8 8 0 1 2 2 4 4 4 4

Mỗi thuật toán sắp xếp dưới đây (thuật toán chuẩn, từ giáo trình) thực hiện bao nhiêu phép so sánh dưới dạng một hàm của n trong trường hợp xấu nhất? Lưu ý rằng độ dài của mảng là 4n chứ không phải n.
Chú ý: Ta viết log để biểu thị logarit cơ số 2 và nhắc lại rằng log(ab) = log a + log b.

Selection sort:  
    ~ ½ n2	~ n2	~2n2	~4n2	~8n2	~16n2		
Insertion sort:  
    ~ ½ n2	~ n2	~2n2	~4n2	~8n2	~16n2		
Mergesort:  
    ~ n log n    ~2n log n 	~4n log n    ~92 n log n    ~8n log n   ~16n log n
3-way quicksort: Giả sử bước tráo ngẫu nhiên cho kết quả là mảng sắp xếp giảm dần	
2n 2n … 2n n n … n …8 8 8 8 8 8 8 8 4 4 4 4 2 2 1 0

(n)	 (n log n)	(n2/ log n)  	(n2) 		 (n2log n) 	  (n4) 

- Selection Sort: vận chạy n lần vòng lặp và n + n - 1 + n - 2 + ... + 1
-> N = 4n -> 4n*(4n - 1) / 2 ~ 8N^2

- Insertion Sort: MNửa đầu toàn số lớn, nửa sau là các số nhỏ hơn 2n -> mỗi phần tử ở nửa sau phải đi qua gần 2n phần tử lớn của 2 nửa đầu

-> 2n * 2n (đi 2 n vòng lặp đầu và đi lại 2n vòng lặp sau) -> 4n^2 

- Merge Sort: N = 4n -> có khoảng log(4n) tầng -> upperbound khoảng 4nlog(4n)

-> 8nlogn(n)


- 3-way Quicksort: chọn pivot -> < p: 0 phần tử, = p 1 phẩn tử -> > pivot: n - 2 phần tử (đầu tiên)


Recurrent: T(N)  =T(N -1) + O(N)

Khai triển:
\[
T(N)
=
N+(N-1)+(N-2)+\cdots+1
\]
\[
=\Theta(N^2)
\]
Mà:
\[
N=4n
\]
nên:
\[
\Theta((4n)^2)
=
\Theta(16n^2)
\]
Nhưng đề hỏi dạng tiệm cận, nên hằng số 16 bị bỏ:
\[
\boxed{\Theta(n^2)}
\]
Đáp án: