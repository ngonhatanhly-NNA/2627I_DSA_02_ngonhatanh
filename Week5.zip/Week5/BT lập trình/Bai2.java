```java
import java.util.Arrays;
import java.util.Random;

public class SortComparison {

    // =========================
    // INSERTION SORT
    // =========================
    public static void insertionSort(int[] a) {

        for (int i = 1; i < a.length; i++) {

            int key = a[i];
            int j = i - 1;

            while (j >= 0 && a[j] > key) {
                a[j + 1] = a[j];
                j--;
            }

            a[j + 1] = key;
        }
    }


    // =========================
    // MERGE SORT
    // =========================
    public static void mergeSort(int[] a) {
        int[] aux = new int[a.length];
        mergeSort(a, aux, 0, a.length - 1);
    }

    private static void mergeSort(
            int[] a,
            int[] aux,
            int lo,
            int hi) {

        if (hi <= lo) {
            return;
        }

        int mid = lo + (hi - lo) / 2;

        mergeSort(a, aux, lo, mid);
        mergeSort(a, aux, mid + 1, hi);

        merge(a, aux, lo, mid, hi);
    }

    private static void merge(
            int[] a,
            int[] aux,
            int lo,
            int mid,
            int hi) {

        for (int k = lo; k <= hi; k++) {
            aux[k] = a[k];
        }

        int i = lo;
        int j = mid + 1;

        for (int k = lo; k <= hi; k++) {

            if (i > mid) {
                a[k] = aux[j++];
            }
            else if (j > hi) {
                a[k] = aux[i++];
            }
            else if (aux[j] < aux[i]) {
                a[k] = aux[j++];
            }
            else {
                a[k] = aux[i++];
            }
        }
    }


    // =========================
    // GENERATE DATA
    // =========================
    public static int[] randomArray(int n) {

        Random random = new Random();

        int[] a = new int[n];

        for (int i = 0; i < n; i++) {
            a[i] = random.nextInt(n);
        }

        return a;
    }


    // =========================
    // TIME MEASUREMENT
    // =========================
    public static double measureInsertionSort(int[] original) {

        int[] a = Arrays.copyOf(original, original.length);

        long start = System.nanoTime();

        insertionSort(a);

        long end = System.nanoTime();

        return (end - start) / 1_000_000.0;
    }


    public static double measureMergeSort(int[] original) {

        int[] a = Arrays.copyOf(original, original.length);

        long start = System.nanoTime();

        mergeSort(a);

        long end = System.nanoTime();

        return (end - start) / 1_000_000.0;
    }


    // =========================
    // MAIN
    // =========================
    public static void main(String[] args) {

        int[] sizes = {
            1000,
            5000,
            10000,
            50000,
            100000
        };

        System.out.printf(
                "%-10s %-20s %-20s%n",
                "N",
                "Insertion Sort (ms)",
                "Merge Sort (ms)"
        );

        System.out.println(
                "------------------------------------------------------"
        );

        for (int n : sizes) {

            int[] data = randomArray(n);

            double insertionTime =
                    measureInsertionSort(data);

            double mergeTime =
                    measureMergeSort(data);

            System.out.printf(
                    "%-10d %-20.3f %-20.3f%n",
                    n,
                    insertionTime,
                    mergeTime
            );
        }
    }
}
```